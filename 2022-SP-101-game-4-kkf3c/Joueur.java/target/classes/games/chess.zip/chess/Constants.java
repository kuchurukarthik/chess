package games.chess;

public final class Constants {
  static char[] promotionPieces = new char[] { 'r', 'b', 'n', 'q' };
}
